<!-- For the button version -->
<script type="text/javascript">
	$(window).load(function() {
		$('.button').raptorize();
	});
</script>

<!-- For the Konami Code version -->
<script type="text/javascript">
	$(window).load(function() {
		$('.button').raptorize({
			'enterOn' : 'konami-code'
		});
	});
</script>